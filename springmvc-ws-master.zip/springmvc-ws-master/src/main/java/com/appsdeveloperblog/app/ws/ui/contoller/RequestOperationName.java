package com.appsdeveloperblog.app.ws.ui.contoller;

public enum RequestOperationName {
	DELETE,
	VERIFY_EMAIL,
	REQUEST_PASSWORD_RESET,
	PASSWORD_RESET
}
