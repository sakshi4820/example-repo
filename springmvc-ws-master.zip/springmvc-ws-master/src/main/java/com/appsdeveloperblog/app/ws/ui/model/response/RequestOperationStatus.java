package com.appsdeveloperblog.app.ws.ui.model.response;

public enum RequestOperationStatus {
	ERROR, SUCCESS
}
